const app = document.getElementById('app');
const list = document.getElementById('list');
const btnClose = document.getElementById('btnClose');
const btnStore = document.getElementById('btnStore');
const backdrop = document.getElementById('backdrop');
const title = document.getElementById('title');

let isImpound = false;

window.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.action === 'open') {
    isImpound = !!data.impound;
    title.textContent = isImpound ? '🛠️ Odťahovka' : '📦 Zdieľaná garáž';
    btnStore.style.display = isImpound ? 'none' : 'inline-block';
    renderVehicles(data.vehicles || []);
    openUI();
  }
  if (data.action === 'forceclose') {
    closeUI();
  }
});

function openUI() {
  app.classList.remove('hidden');
  app.setAttribute('aria-hidden', 'false');
  // NUI focus is set from client.lua; UI should be interactive
  // allow ESC to close
  document.addEventListener('keydown', escHandler);
  backdrop.addEventListener('click', closeUI);
}

function closeUI() {
  fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: '{}' });
  app.classList.add('hidden');
  app.setAttribute('aria-hidden', 'true');
  document.removeEventListener('keydown', escHandler);
  backdrop.removeEventListener('click', closeUI);
}

function escHandler(e) {
  if (e.key === 'Escape') closeUI();
}

btnClose.addEventListener('click', closeUI);

btnStore.addEventListener('click', () => {
  btnStore.disabled = true;
  fetch(`https://${GetParentResourceName()}/store`, { method: 'POST', body: '{}' })
    .then(res => res.json())
    .finally(() => { btnStore.disabled = false; });
});

function renderVehicles(vehicles) {
  list.innerHTML = '';
  if (!vehicles.length) {
    list.innerHTML = '<div style="padding:12px; opacity:0.8;">Žiadne vozidlá na zobrazenie.</div>';
    return;
  }
  vehicles.forEach(v => {
    const item = document.createElement('div');
    item.className = 'item';
    const statusClass = v.impounded == 1 ? 'red' : (v.stored == 1 ? 'green' : 'yellow');
    const disabled = isImpound ? (v.impounded != 1) : (v.stored != 1 || v.impounded == 1);
    item.innerHTML = `
      <div class="col">
        <span class="badge ${statusClass}">${v.impounded == 1 ? 'v odťahovke' : (v.stored == 1 ? 'garáži' : 'vonku')}</span>
        <span>${v.displayName || v.model}</span>
      </div>
      <div class="col">
        <span class="plate">${v.plate}</span>
        <button class="btn small" ${disabled ? 'disabled' : ''}>Vybrať</button>
      </div>
    `;
    const btn = item.querySelector('button');
    btn.addEventListener('click', () => {
      btn.disabled = true;
      fetch(`https://${GetParentResourceName()}/takeout`, { method: 'POST', body: JSON.stringify({ plate: v.plate, impound: isImpound }) })
        .then(res => res.json())
        .finally(() => { btn.disabled = false; });
    });
    list.appendChild(item);
  });
}
