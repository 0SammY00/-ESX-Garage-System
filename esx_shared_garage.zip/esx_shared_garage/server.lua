ESX = exports['es_extended']:getSharedObject()

-- Return player's vehicles
ESX.RegisterServerCallback('esx_shared_garage:getVehicles', function(source, cb)
  local xPlayer = ESX.GetPlayerFromId(source)
  if not xPlayer then cb({}); return end
  local identifier = xPlayer.getIdentifier()

  MySQL.Async.fetchAll('SELECT plate, vehicle, stored, IFNULL(impounded,0) as impounded FROM owned_vehicles WHERE owner = @owner', {
    ['@owner'] = identifier
  }, function(result)
    local vehicles = {}
    for _, row in ipairs(result) do
      local ok, veh = pcall(function() return json.decode(row.vehicle) end)
      local model = ok and veh.model or tostring(row.vehicle)
      local status = 'garáži'
      if row.impounded == 1 then status = 'v odťahovke' elseif row.stored == 0 then status = 'vonku' end
      table.insert(vehicles, {
        plate = row.plate,
        model = model,
        displayName = tostring(model),
        stored = row.stored,
        impounded = row.impounded,
        status = status
      })
    end
    cb(vehicles)
  end)
end)

-- Store vehicle (owner only). Sets stored=1 and impounded=0 deterministically.
ESX.RegisterServerCallback('esx_shared_garage:storeVehicle', function(source, cb, vehProps)
  local xPlayer = ESX.GetPlayerFromId(source)
  if not xPlayer then cb(false, 'Interná chyba'); return end
  local identifier = xPlayer.getIdentifier()
  local plate = vehProps.plate

  MySQL.Async.fetchAll('SELECT id FROM owned_vehicles WHERE owner=@owner AND plate=@plate LIMIT 1', {
    ['@owner'] = identifier,
    ['@plate'] = plate
  }, function(rows)
    if rows[1] then
      MySQL.Async.execute('UPDATE owned_vehicles SET vehicle=@vehicle, stored=1, impounded=0 WHERE id=@id', {
        ['@vehicle'] = json.encode(vehProps),
        ['@id'] = rows[1].id
      }, function(affected)
        cb(affected > 0, affected > 0 and nil or 'Nepodarilo sa uložiť.')
      end)
    else
      cb(false, 'Toto vozidlo nevlastníš.')
    end
  end)
end)

-- Take out vehicle. If fromImpound true, allow even if impounded.
ESX.RegisterServerCallback('esx_shared_garage:takeOutVehicle', function(source, cb, plate, fromImpound)
  local xPlayer = ESX.GetPlayerFromId(source)
  if not xPlayer then cb(false, 'Interná chyba'); return end
  local identifier = xPlayer.getIdentifier()

  MySQL.Async.fetchAll('SELECT id, vehicle, stored, IFNULL(impounded,0) as impounded FROM owned_vehicles WHERE owner=@owner AND plate=@plate LIMIT 1', {
    ['@owner'] = identifier,
    ['@plate'] = plate
  }, function(rows)
    local r = rows[1]
    if not r then cb(false, 'Toto vozidlo nevlastníš.'); return end

    if r.impounded == 1 and not fromImpound then
      cb(false, 'Vozidlo je v odťahovke.'); return
    end
    if r.stored == 0 and not fromImpound then
      cb(false, 'Vozidlo je už vonku.'); return
    end

    -- set stored=0 and impounded=0 when taking out
    MySQL.Async.execute('UPDATE owned_vehicles SET stored=0, impounded=0 WHERE id=@id', {
      ['@id'] = r.id
    }, function(affected)
      if affected > 0 then
        cb(true, nil, json.decode(r.vehicle))
      else
        cb(false, 'Nepodarilo sa vybrať vozidlo.')
      end
    end)
  end)
end)

-- Mark by plate as impounded (runs regardless who deleted vehicle)
RegisterNetEvent('esx_shared_garage:markImpounded')
AddEventHandler('esx_shared_garage:markImpounded', function(plate)
  if not plate then return end
  MySQL.Async.execute('UPDATE owned_vehicles SET stored=0, impounded=1 WHERE plate=@plate', {
    ['@plate'] = plate
  })
end)
