fx_version 'cerulean'
game 'gta5'

name 'esx_shared_garage'
author '0SammY0'
description 'ESX Shared Garage - stable v7'
version '1.3.0'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/script.js'
}

shared_script 'config.lua'

client_scripts {
  '@es_extended/locale.lua',
  'client.lua'
}

server_scripts {
  '@mysql-async/lib/MySQL.lua',
  'server.lua'
}

dependencies {
  'es_extended'
}
