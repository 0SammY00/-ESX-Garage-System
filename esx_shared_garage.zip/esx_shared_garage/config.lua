Config = {}

-- Each garage: Menu (open UI), Store (park to save), Spawn (spawn vehicle), Heading
Config.Garages = {
  { Menu = vector3(212.8354, -796.2483, 30.8658), Store = vector3(232.3186, -793.0023, 30.5905), Spawn = vector3(234.2365, -785.5781, 30.6284), Heading = 158.5691 },
  { Menu = vector3(-334.31, 289.26, 84.70), Store = vector3(-344.5797, 294.5728, 85.2183), Spawn = vector3(-334.6700, 277.9185, 85.9493), Heading = 174.3822 },
  { Menu = vector3(-451.82, -794.50, 30.56), Store = vector3(-453.5270, -803.6027, 30.5402), Spawn = vector3(-471.9502, -807.7521, 30.5396), Heading = 183.1909 },
  { Menu = vector3(639.32, 206.20, 97.34), Store = vector3(642.5, 210.7, 96.90), Spawn = vector3(645.0, 213.9, 96.70), Heading = 155.0 },
  { Menu = vector3(-1197.2520, -1486.5850, 4.3797), Store = vector3(-1188.5083, -1496.4719, 4.3797), Spawn = vector3(-1184.1078, -1500.7518, 4.3797), Heading = 215.7359 },
  { Menu = vector3(1737.93, 3710.71, 34.14), Store = vector3(1740.4115, 3719.8220, 34.0266), Spawn = vector3(1728.8376, 3724.1873, 34.0278), Heading = 33.7261 },
  { Menu = vector3(1159.2909, -1496.7206, 34.6925), Store = vector3(1165.5162, -1497.2539, 34.6925), Spawn = vector3(1164.6603, -1505.8281, 34.6925), Heading = 85.0826 },
  { Menu = vector3(113.6174, 6611.3101, 31.8633), Store = vector3(123.1098, 6600.5923, 31.9501), Spawn = vector3(127.5027, 6610.2378, 31.8488), Heading = 221.8755 },
  { Menu = vector3(-73.42, -2004.38, 18.02), Store = vector3(-76.9, -1999.4, 18.00), Spawn = vector3(-79.9, -1995.0, 18.00), Heading = 320.0 },
  { Menu = vector3(-313.56, -1033.37, 30.53), Store = vector3(-317.5452, -1026.0645, 30.3850), Spawn = vector3(-316.4619, -1020.1436, 30.3850), Heading = 341.0513 }
}

-- Impound (odťahovka)
Config.Impound = {
  Menu = vector3(409.0, -1623.0, 29.3),
  Spawn = vector3(401.5, -1631.8, 29.3),
  Heading = 230.0,
  Blip = { sprite = 68, color = 1, scale = 0.8, name = 'Odťahovka' }
}

-- Markers & blips
Config.DrawDistance = 30.0
Config.MarkerMenu = { type = 36, x = 1.5, y = 1.5, z = 1.0, r = 255, g = 255, b = 255, a = 180 }
Config.MarkerStore = { type = 36, x = 2.0, y = 2.0, z = 1.0, r = 255, g = 255, b = 255, a = 180 }
Config.MarkerImpound = { type = 36, x = 1.8, y = 1.8, z = 1.0, r = 255, g = 255, b = 255, a = 200 }

Config.BlipGarage = { sprite = 357, color = 3, scale = 0.7, name = 'Garáž' }

Config.OpenKey = 38 -- E

Config.OwnershipCheck = true
Config.PreventDuplicateTakeOut = true
