ESX = exports['es_extended']:getSharedObject()
local uiOpen = false
local nearMenuIndex, nearStoreIndex, atImpound = nil, nil, false
local lastSpawned = nil -- { entity, plate }
local ignoreDeletes = {} -- plates we intentionally deleted on store


-- Create blips
Citizen.CreateThread(function()
  for i,g in ipairs(Config.Garages) do
    local blip = AddBlipForCoord(g.Menu.x, g.Menu.y, g.Menu.z)
    SetBlipSprite(blip, Config.BlipGarage.sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, Config.BlipGarage.scale)
    SetBlipColour(blip, Config.BlipGarage.color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING'); AddTextComponentString(Config.BlipGarage.name); EndTextCommandSetBlipName(blip)
  end
  -- Impound blip
  local ib = AddBlipForCoord(Config.Impound.Menu.x, Config.Impound.Menu.y, Config.Impound.Menu.z)
  SetBlipSprite(ib, Config.Impound.Blip.sprite)
  SetBlipDisplay(ib, 4)
  SetBlipScale(ib, Config.Impound.Blip.scale)
  SetBlipColour(ib, Config.Impound.Blip.color)
  SetBlipAsShortRange(ib, true)
  BeginTextCommandSetBlipName('STRING'); AddTextComponentString(Config.Impound.Blip.name); EndTextCommandSetBlipName(ib)
end)

-- Draw markers and notifications
Citizen.CreateThread(function()
  while true do
    local sleep = 1000
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    nearMenuIndex, nearStoreIndex, atImpound = nil, nil, false

    for i,g in ipairs(Config.Garages) do
      local dMenu = #(coords - g.Menu)
      if dMenu < Config.DrawDistance then
        sleep = 0
        DrawMarker(Config.MarkerMenu.type, g.Menu.x, g.Menu.y, g.Menu.z - 0.5, 0.0,0.0,0.0, 0.0,0.0,0.0, Config.MarkerMenu.x, Config.MarkerMenu.y, Config.MarkerMenu.z, Config.MarkerMenu.r, Config.MarkerMenu.g, Config.MarkerMenu.b, Config.MarkerMenu.a, false, true, 2, false, nil, nil, false)
        if dMenu < 2.0 then
          nearMenuIndex = i
          ESX.ShowHelpNotification('Stlač ~INPUT_CONTEXT~ pre otvorenie garáže')
        end
      end

      local dStore = #(coords - g.Store)
      if dStore < Config.DrawDistance then
        sleep = 0
        DrawMarker(Config.MarkerStore.type, g.Store.x, g.Store.y, g.Store.z - 0.5, 0.0,0.0,0.0, 0.0,0.0,0.0, Config.MarkerStore.x, Config.MarkerStore.y, Config.MarkerStore.z, Config.MarkerStore.r, Config.MarkerStore.g, Config.MarkerStore.b, Config.MarkerStore.a, false, true, 2, false, nil, nil, false)
        if dStore < 3.0 then
          nearStoreIndex = i
          ESX.ShowHelpNotification('Stlač ~INPUT_CONTEXT~ pre uloženie vozidla')
        end
      end
    end

    local di = #(coords - Config.Impound.Menu)
    if di < Config.DrawDistance then
      sleep = 0
      DrawMarker(Config.MarkerImpound.type, Config.Impound.Menu.x, Config.Impound.Menu.y, Config.Impound.Menu.z - 0.5, 0.0,0.0,0.0, 0.0,0.0,0.0, Config.MarkerImpound.x, Config.MarkerImpound.y, Config.MarkerImpound.z, Config.MarkerImpound.r, Config.MarkerImpound.g, Config.MarkerImpound.b, Config.MarkerImpound.a, false, true, 2, false, nil, nil, false)
      if di < 2.0 then
        atImpound = true
        ESX.ShowHelpNotification('Stlač ~INPUT_CONTEXT~ pre otvorenie odťahovky')
      end
    end

    Citizen.Wait(sleep)
  end
end)

-- Interactions
Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    if nearMenuIndex and IsControlJustReleased(0, Config.OpenKey) then
      OpenGarageUI(false)
    elseif atImpound and IsControlJustReleased(0, Config.OpenKey) then
      OpenGarageUI(true)
    elseif nearStoreIndex and IsControlJustReleased(0, Config.OpenKey) then
      StoreAtGarage(nearStoreIndex)
    end
  end
end)

function OpenGarageUI(fromImpound)
  ESX.TriggerServerCallback('esx_shared_garage:getVehicles', function(vehicles)
    if fromImpound then
      local only = {}
      for _,v in ipairs(vehicles) do if v.impounded == 1 then table.insert(only, v) end end
      vehicles = only
    end
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', vehicles = vehicles, impound = fromImpound })
    uiOpen = true
  end)
end

RegisterNUICallback('close', function(data, cb)
  SetNuiFocus(false, false)
  uiOpen = false
  cb('ok')
end)

RegisterNUICallback('takeout', function(data, cb)
  local plate = data.plate
  local fromImpound = data.impound or false
  local spawnPos, heading
  if fromImpound then
    spawnPos = Config.Impound.Spawn
    heading = Config.Impound.Heading
  else
    local idx = GetClosestGarageIndex()
    if not idx then ESX.ShowNotification('Nie si pri garáži.'); cb({ ok = false }); return end
    local g = Config.Garages[idx]
    spawnPos = g.Spawn; heading = g.Heading or 0.0
  end

  ESX.TriggerServerCallback('esx_shared_garage:takeOutVehicle', function(success, msg, vehProps)
    if success then
      SetNuiFocus(false, false)
uiOpen = false
SendNUIMessage({ action = 'forceclose' })
ESX.Game.SpawnVehicle(vehProps.model, spawnPos, heading, function(vehicle)
        ESX.Game.SetVehicleProperties(vehicle, vehProps)
        SetVehicleNumberPlateText(vehicle, vehProps.plate)
        TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
        ESX.ShowNotification((fromImpound and '~g~Prevzaté z odťahovky:~s~ ' or 'Vozidlo vybraté: ') .. vehProps.plate)
        StartImpoundWatcher(vehicle, vehProps.plate)
        lastSpawned = { entity = vehicle, plate = vehProps.plate }
      end)
      cb({ ok = true })
    else
      ESX.ShowNotification(msg or 'Nepodarilo sa vybrať vozidlo.')
      cb({ ok = false, error = msg })
    end
  end, plate, fromImpound)
end)

function StoreAtGarage(index)
  local ped = PlayerPedId()
  local veh = GetVehiclePedIsIn(ped, false)
  if veh == 0 then ESX.ShowNotification('Nie si vo vozidle.'); return end
  local g = Config.Garages[index]
  if #(GetEntityCoords(veh) - g.Store) > 5.0 then
    ESX.ShowNotification('Postav vozidlo na označené miesto.'); return
  end
  local props = ESX.Game.GetVehicleProperties(veh)
  ESX.TriggerServerCallback('esx_shared_garage:storeVehicle', function(success, msg)
    if success then
      -- mark plate to ignore delete watcher, clear after 8s
      if props and props.plate then
        ignoreDeletes[props.plate] = true
        Citizen.SetTimeout(8000, function() ignoreDeletes[props.plate] = nil end)
      end
      ESX.Game.DeleteVehicle(veh)
      ESX.ShowNotification('Vozidlo uložené: ' .. props.plate)
    else
      ESX.ShowNotification(msg or 'Toto vozidlo nevlastníš.')
    end
  end, props)
end

function GetClosestGarageIndex()
  local coords = GetEntityCoords(PlayerPedId())
  local best, bestDist = nil, 9999.0
  for i,g in ipairs(Config.Garages) do
    local d = #(coords - g.Menu)
    if d < bestDist then bestDist = d; best = i end
  end
  if bestDist <= 50.0 then return best end
  return nil
end

function StartImpoundWatcher(entity, plate)
  Citizen.CreateThread(function()
    local ticks = 0
    while true do
      Citizen.Wait(1000)
      ticks = ticks + 1
      if not DoesEntityExist(entity) then
        -- ignore intended deletions
        if plate and ignoreDeletes[plate] then ignoreDeletes[plate] = nil; return end
        -- mark by plate on server
        if plate then TriggerServerEvent('esx_shared_garage:markImpounded', plate) end
        return
      end
      -- safety timeout: watcher stops after 5 minutes if still exists
      if ticks > 300 then return end
    end
  end)
end